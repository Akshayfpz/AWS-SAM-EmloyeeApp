'use strict';

const AWS = require('aws-sdk');
const s3 = new AWS.S3();

const s3Bucket = process.env.STRINGS_BUCKET_NAME;
const objectName = process.env.STRINGS_JSON_FILE;
const objectType = "application/json";

exports.handler = async (event, context, callback) => {
    const http_Method = event['httpMethod'];
    
    if (http_Method === 'GET'){
        let response = getDataFromS3();
        return response;
    }else if (http_Method === 'POST'){
        if (event.body !== null && event.body !== undefined) {
            
            let body = event.body;
            let Name = body.name;
            let Age = body.age;
            
            let response = PostDataToS3(Name,Age);
            return response;
        }
    }
};
// This function for read file from s3 bucket
async function getDataFromS3(){
    try {
        const params = {
            Bucket: s3Bucket,
            Key: objectName
        };
        const result = await s3.getObject(params).promise();
        return sendRes(200, result.Body.toString());

    } catch (error) {
        return sendRes(404, error);
    }
}
// This function for Write file to s3 bucket
async function PostDataToS3(Name,Age){
    const objectData = '{ "Name" : '+Name+', "Age": '+Age+' }';
    try {
        const params = {
            Bucket: s3Bucket,
            Key: objectName,
            Body: objectData,
            ContentType: objectType
        };
        const result = await s3.putObject(params).promise();
        return sendRes(200, `File uploaded successfully at https:/` + s3Bucket + `.s3.amazonaws.com/` + objectName);

    } catch (error) {
        return sendRes(404, error);
    }
}
// This function for handling 
const sendRes = (status, body) => {
    var response = {
        statusCode: status,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "OPTIONS,POST,PUT",
            "Access-Control-Allow-Credentials": true,
            "Access-Control-Allow-Origin": "*",
            "X-Requested-With": "*"
        },
        body: body
    };
    return response;
};